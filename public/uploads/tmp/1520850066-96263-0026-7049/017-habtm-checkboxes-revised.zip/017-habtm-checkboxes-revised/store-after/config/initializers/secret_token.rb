# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Store::Application.config.secret_token = 'ded94729d57cfed50900e137075ac9916071fdf1fdc4fd28dfd56bff5a9911766ced98262ebd3ee116e0848775d4455bb6e98edbb7a7fbd615ba51a1860989d5'
